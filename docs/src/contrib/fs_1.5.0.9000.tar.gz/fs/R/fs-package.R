#' @description
#' \ifelse{html}{
#' \out{
#' <a href="https://www.tidyverse.org/lifecycle/#maturing">
#'   <img src="https://img.shields.io/badge/lifecycle-maturing-blue.svg" alt="Maturing lifecycle">
#' </a>
#' }
#' }{
#' \url{https://www.tidyverse.org/lifecycle/#maturing}
#' }
#' @keywords internal
"_PACKAGE"
