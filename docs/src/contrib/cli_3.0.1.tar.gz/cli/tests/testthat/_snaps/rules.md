# print.rule

    Code
      rule("foo")
    Output
      -- foo -------------

